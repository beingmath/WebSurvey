package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/insertQuestionServlet")
public class insertQuestionServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		'pro' : $issue,
//		'option' : $time,
//		'A' : $a,
//		'A' : $b,
//		'A' : $c,
//		'A' : $d,
//		'task' : $value
		response.setContentType("text/text;charset=utf-8");
		response.setCharacterEncoding("UTF-8");
		String pro=request.getParameter("pro");
	String option=request.getParameter("option");
//	String A=request.getParameter("A");
//	String B=request.getParameter("B");
//	String C=request.getParameter("C");
//	String D=request.getParameter("D");
//	String task=request.getParameter("task");
	System.out.println(pro+option);
	response.getWriter().print("true");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
